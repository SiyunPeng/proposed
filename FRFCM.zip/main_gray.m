clc
close all     
clear all   
%% test a gray image 
f_ori=imread('');
fn=f_ori;
figure(1);subplot(1,2,1);imshow(uint8(f_ori));
[m,n]=size(f_ori);
%% parameters
cluster=3; 
se=3; 
w_size=3; 
%% segment an image corrupted by noise
tic 
[center1,U1,~,t1]=FRFCM(double(fn),cluster,se,w_size);
Time1=toc;
disp(strcat('����ʱ��: ',num2str(Time1)))
f_seg=fcm_image(f_ori,U1,center1);
% imshow(fn),title('Original image');
% figure,imshow(f_seg);title('segmentated result');
u=reshape(U1,cluster,m,n);
image2=zeros(m,n);
for x=1:m
    for y=1:n
        if cluster==4
            if u(1,x,y)>u(2,x,y) && u(1,x,y)>u(3,x,y) && u(1,x,y)> u(4,x,y)
                image2(x,y)=0;
            end
            if u(2,x,y)>u(1,x,y) && u(2,x,y)>u(3,x,y) && u(2,x,y)> u(4,x,y)
                image2(x,y)=64;
            end
            if u(3,x,y)>u(1,x,y) && u(3,x,y)>u(2,x,y) && u(3,x,y)>u(4,x,y)
                image2(x,y)=150;
            end
            if u(4,x,y)>u(1,x,y)&& u(4,x,y)>u(2,x,y) && u(4,x,y)>u(3,x,y)
                image2(x,y)=255;
            end
        end
        if cluster==3
            if u(1,x,y)>u(2,x,y) && u(1,x,y)>u(3,x,y)
                image2(x,y)=125;
            end
            if u(2,x,y)>u(1,x,y) && u(2,x,y)>u(3,x,y)
                image2(x,y)=255;
            end
            if u(3,x,y)>u(1,x,y) && u(3,x,y)>u(2,x,y)
                image2(x,y)=0;
            end
        end
        if cluster==2
            if u(1,x,y)>u(2,x,y)
                image2(x,y)=0;
            else
                image2(x,y)=255;
            end
        end
    end
end
figure(2);imshow(uint8(image2));
