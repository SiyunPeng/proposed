%% Initialization
clc
clear all;
close all;
%% Input image
f_uint8 = imread(''); 
f = double(f_uint8);
%% Parameters
density = 0.2;
error = 0.1;
cluster_num =3;
max_iter = 200;
gamma = 0.15;
k = 50;
d = 5;
% Parameters for region-level information
l = 9;
S = 15;
g = 5; 
sigma = 4;
figure(1);subplot(1,2,1);imshow(uint8(f);
tt=clock;
%% Acquire region_level information
f_region_information = region_level_information(f, l, S, g, sigma);
% figure, imshow(uint8(f_region_information));
% title('Image of region level-information I_R');
%% Nomalization
f_region_information = f_region_information / 255;
f = f / 255;
%% Mean template of region-level information
mask = fspecial('average', 7);
f_local = imfilter(f_region_information, mask, 'symmetric');
%% Calculate adaptive weights ξ_jz (denoted as xi in this file) in Eq. (15)
[row, col, depth] = size(f);
n = row * col;
xi = zeros(row, col, depth);
phi = (255 * (f_local - f_region_information)) .^ 2; % Eq. (13)
phi_padded = padarray(phi, [1 1], 'symmetric');
phi_std = stdfilt(phi, ones(3)) + eps; % δ_jz
for i = -1 : 1
    for j = -1 : 1
        xi = xi + (exp(abs(phi_padded(i + 1 + 1 : end + i - 1, j + 1 + 1 : end + j - 1, :) - phi) ./ phi_std) - 1); % Eq. (14)
    end
end
min_xi = min(min(min(xi)));
max_xi = max(max(max(xi)));
xi =(xi - min_xi)./(max_xi-min_xi); % Eq. (15)
xi = repmat(reshape(xi, n, 1, depth), [1 cluster_num 1]);
%% Calculate Eq. (21)
difference = k * exp(stdfilt(f, ones(3)) - stdfilt(f_region_information, ones(3))) + eps;
difference = repmat(reshape(difference, row * col, 1, depth), [1 cluster_num 1]);
%% Size reshaping
f = repmat(reshape(f, n, 1, depth), [1 cluster_num 1]);
f_region_information = repmat(reshape(f_region_information, n, 1, depth), [1 cluster_num 1]);
f_local = repmat(reshape(f_local, n, 1, depth), [1 cluster_num 1]);
%% Initialization of clustering
% Membership degrees
U =rand(n, cluster_num);
% Eq. (22)
alpha = 1 ./ difference;
% Eq. (23)
beta = difference;
% 5x5 membership degrees local area
U_cluster1_local_5x5 = zeros(5, 5, max_iter); % cluster_1
U_cluster2_local_5x5 = zeros(5, 5, max_iter); % cluster_2
% Process U
U_col_sum = sum(U, 2);
U_col_sum = repmat(U_col_sum, [1 cluster_num]);
U = U ./ U_col_sum;
%% Fuzzy clustering
for iter = 1 : max_iter
    % Locally median membership degrees Eq. (18)
    half_d = floor(d  / 2);
    U = reshape(U, row, col, cluster_num);
    pi = zeros(row, col, cluster_num);
    for i = 1 : cluster_num
        pi(:, :, i) = medfilt2(gather(U(:, :, i)), [d, d], 'symmetric');
    end
    U = reshape(U, row * col, cluster_num);
    pi = reshape(pi, row * col, cluster_num);
    % Update cluster centers by Eq. (32)
    U_rep = repmat(U, [1 1 depth]);
    center = sum(alpha .* U_rep .* f + beta .* U_rep .* (xi .* f_local + (1 - xi) .* f_region_information)) ./ sum((alpha + beta) .* U_rep);
    % Compute Euclidean distance
    center_rep = repmat(center, [n 1 1]);
    dist_a = mean(alpha .* (f - center_rep) .^2, 3);
    dist_b = mean(beta .* (xi .* (f_local - center_rep) .^ 2 + (1 - xi) .* (f_region_information - center_rep) .^ 2), 3);
    dist = dist_a + dist_b;
    % Update membership degrees by Eq. (31)
    U_numerator = pi .* exp(-(pi .* gamma + dist) ./ gamma) + eps;
    U = U_numerator ./ repmat(sum(U_numerator, 2), [1 cluster_num]);
    % Check local membership degrees
    U_reshape1 = reshape(U(:, 1), row, col);
    U_reshape2 = reshape(U(:, 2), row, col);
    U_cluster1_local_5x5(:, :, iter) = U_reshape1(60 : 64, 20 : 24); % 60 64 20 24 are collected randomly
    U_cluster2_local_5x5(:, :, iter) = U_reshape2(60 : 64, 20 : 24);
end
center = uint8(squeeze(center * 255));
%% Output segmentation result
[~, cluster_indice] = max(U, [], 2);
% Visualize all labels
FCM_result = Label_image(f_uint8, reshape(cluster_indice, row, col));
u=reshape(U,row, col,cluster_num);
c=cluster_num;
disp(['����ʱ��:  ',num2str(etime(clock,tt))]);
image2=zeros(m,n);
 for x=1:m
     for y=1:n
         if c==2
             if u(x,y,1)>u(x,y,2)
                 image2(x,y)=0;
             else
                 image2(x,y)=255;
             end
         end
         if c==3
             if u(x,y,1)>u(x,y,2) && u(x,y,1)>u(x,y,3)
                 image2(x,y)=0;
             end
             if u(x,y,2)>u(x,y,1)  && u(x,y,2)>u(x,y,3)
                 image2(x,y)=125;
             end
             if u(x,y,3)>u(x,y,1)&& u(x,y,3)>u(x,y,2)
                 image2(x,y)=255;
             end
         end
         if c==4
             if u(x,y,1)>u(x,y,2) && u(x,y,1)>u(x,y,3)&&u(x,y,1)>u(x,y,4)
                 image2(x,y)=0;
             end
             if u(x,y,2)>u(x,y,1) && u(x,y,2)>u(x,y,3)&&u(x,y,2)>u(x,y,4)
                 image2(x,y)=150;
             end
             if u(x,y,3)>u(x,y,1)&& u(x,y,3)>u(x,y,2)&& u(x,y,3)>u(x,y,4)
                 image2(x,y)=64;
             end
             if u(x,y,4)>u(x,y,1)&& u(x,y,4)>u(x,y,2)&& u(x,y,4)>u(x,y,3)
                 image2(x,y)=255;
             end
         end
     end
 end
figure(2);imshow(uint8(image2));
